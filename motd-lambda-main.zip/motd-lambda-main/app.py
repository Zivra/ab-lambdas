from flask import Flask, jsonify, make_response
import json

app = Flask(__name__)


@app.route("/motd")
def motd():
    return jsonify(message='Today is a good day to be a good day!')


@app.route("/version")
def version():
    with open('version.json') as f:
        data = json.load(f)
        return jsonify(version=data['version'])



@app.errorhandler(404)
def resource_not_found(e):
    return make_response(jsonify(error='Not found!'), 404)
